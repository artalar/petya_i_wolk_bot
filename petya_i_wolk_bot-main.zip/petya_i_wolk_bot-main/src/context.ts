import { Context as BaseContext, SessionFlavor } from 'grammy';
import { SessionData } from './types.js';

export type Context = BaseContext & SessionFlavor<SessionData>;

